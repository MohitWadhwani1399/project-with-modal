import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-people-picker',
  templateUrl: './people-picker.component.html',
  styleUrls: ['./people-picker.component.scss']
})
export class PeoplePickerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
