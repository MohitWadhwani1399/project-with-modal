export const USERS = [
    {
      GPGID: "1",  
      firstName: 'Kshitij',
        lastName: 'Srivastava',
        level: 'TECH Round1',
        status:'Rejected',
        location:"Pune",
        jobTitle: 'Angular UI',
        date:'11-Jan-2021'
      },
      {
        GPGID: "2",
        firstName: 'Sriyansh',
        lastName: 'Jain',
        level: 'TECH Round2',
        status:'Selected',
        location:"Pune",
        jobTitle: 'Angular UI',
        date:'11-Jan-2021'
      },
      {
        GPGID: "3",
        firstName: 'Riya',
        lastName: 'Singh',
        level: 'HR Round',
        status:'Pending',
        location:"Mumbai",
        jobTitle: 'Front-end Developer',
        date:'11-Jan-2021'
      },
      {
        GPGID: "4",
        firstName: 'Lokhi',
        lastName: 'Nalam',
        level: 'HR Round',
        status:'Pending',
        location:"Hyderabad",
        jobTitle: 'WEB DEV',
        date:'11-Jan-2021'
      },
      {
        GPGID: "5",
        firstName: 'Shreya',
        lastName: 'Singh',
        level: 'TECH Round2',
        status:'Selected',
        location:"Hyderabad",
        jobTitle: 'DevOps',
        date:'16-Nov-2020'
      },
      {
        GPGID: "6",
        firstName: 'Mohit',
        lastName: 'Wadhwani',
        level: 'TECH Round1',
        status:'Rejected',
        location:"Delhi",
        jobTitle: 'React UI',
        date:'11-Jan-2021'
      }
    ];
    