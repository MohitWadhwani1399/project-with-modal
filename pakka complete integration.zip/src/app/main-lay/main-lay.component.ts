import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-lay',
  templateUrl: './main-lay.component.html',
  styleUrls: ['./main-lay.component.scss']
})
export class MainLayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
